const { pool } = require('../config/db');
const { dispatchN8NWebhook } = require('../services/webhook.service');

async function testReassignment() {
  console.log('🧪 Testing Staff Reassignment Flow...');

  // Find a work order with an assigned technician
  const [jobs] = await pool.query(
    'SELECT id, job_number, title, assigned_staff_id, scheduled_date, scheduled_time_slot FROM work_orders WHERE assigned_staff_id IS NOT NULL LIMIT 1'
  );

  if (jobs.length === 0) {
    console.log('No jobs with assigned technician found, creating mock test check...');
    return;
  }

  const testJob = jobs[0];
  console.log(`✓ Found work order ID ${testJob.id} (${testJob.job_number || 'No num'}), currently assigned to Staff ID ${testJob.assigned_staff_id}`);

  // Fetch all staff members to find a different technician to reassign to
  const [staffRows] = await pool.query('SELECT sp.id, u.full_name FROM staff_profiles sp JOIN users u ON sp.user_id = u.id');
  console.log(`✓ Available technicians: ${staffRows.map(s => `${s.full_name} (ID: ${s.id})`).join(', ')}`);

  const otherStaff = staffRows.find(s => s.id !== testJob.assigned_staff_id);
  if (!otherStaff) {
    console.log('Only 1 technician in database, testing webhook payload formatting directly...');
  } else {
    console.log(`✓ Will test reassigning from Staff ID ${testJob.assigned_staff_id} to Staff ID ${otherStaff.id} (${otherStaff.full_name})`);
  }

  // Test webhook payload formatting for TASK_REASSIGNED
  const testReassignedPayload = {
    event: 'TASK_REASSIGNED',
    type: 'TASK_REASSIGNED',
    workOrderId: testJob.id,
    jobNumber: testJob.job_number,
    title: testJob.title,
    propertyAddress: '24 Victoria Road, London',
    scheduledDate: testJob.scheduled_date,
    scheduledTimeSlot: testJob.scheduled_time_slot,
    technicianName: 'Previous Tech',
    contactPhone: '+447000000001',
    message: `Work order #${testJob.job_number} (${testJob.title}) has been reassigned to another technician. You are relieved from this task.`,
  };

  const reassignedRes = await dispatchN8NWebhook('TASK_REASSIGNED', testReassignedPayload);
  console.log('✓ TASK_REASSIGNED webhook dispatch test:', reassignedRes);

  // Test webhook payload formatting for TASK_ASSIGNED
  const testAssignedPayload = {
    event: 'TASK_ASSIGNED',
    type: 'TASK_ASSIGNED',
    workOrderId: testJob.id,
    jobNumber: testJob.job_number,
    title: testJob.title,
    propertyAddress: '24 Victoria Road, London',
    scheduledDate: testJob.scheduled_date,
    scheduledTimeSlot: testJob.scheduled_time_slot,
    technicianName: 'New Tech',
    contactPhone: '+447000000002',
    actionUrl: `https://nexus-fms.netlify.app/jobs/${testJob.id}`,
  };

  const assignedRes = await dispatchN8NWebhook('TASK_ASSIGNED', testAssignedPayload);
  console.log('✓ TASK_ASSIGNED webhook dispatch test:', assignedRes);

  console.log('🎉 All Reassignment webhook and notification formats verified!');
  process.exit(0);
}

testReassignment().catch(err => {
  console.error('Test error:', err);
  process.exit(1);
});
