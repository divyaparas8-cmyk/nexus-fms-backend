const { dispatchN8NWebhook } = require('../services/webhook.service');

async function testPayloads() {
  console.log('Testing TASK_ASSIGNED normalization...');
  const minimalTaskPayload = {
    workOrderId: 221,
    title: 'ac repair immidetly',
    technicianName: 'lightlab',
    contactPhone: '+44700000000',
    address: 'Indore City',
  };

  const res1 = await dispatchN8NWebhook('TASK_ASSIGNED', minimalTaskPayload);
  console.log('TASK_ASSIGNED result:', res1.event || res1);

  console.log('Testing JOB_COMPLETED normalization...');
  const completePayload = {
    workOrderId: 221,
    jobNumber: 221,
    title: 'ac repair immidetly',
    technicianName: 'lightlab',
    technicianPhone: '+44700000000',
    residentName: 'mukul kiaantechnology',
    propertyAddress: 'Indore City',
    completionReport: 'Repaired AC compressor and replaced filter.',
  };

  const res2 = await dispatchN8NWebhook('JOB_COMPLETED', completePayload);
  console.log('JOB_COMPLETED result:', res2.event || res2);
}

testPayloads().then(() => {
  console.log('Test completed successfully.');
  process.exit(0);
}).catch(err => {
  console.error('Test error:', err);
  process.exit(1);
});
