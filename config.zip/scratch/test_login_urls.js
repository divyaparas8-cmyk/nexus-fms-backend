const axios = require('axios');

async function testLogins() {
  const urls = [
    'https://nexus-fms-backend-production.up.railway.app/api/v1/auth/login',
    'https://nexusfmsbackednshrikant-production.up.railway.app/api/v1/auth/login',
  ];

  for (const url of urls) {
    console.log('\nTesting URL:', url);
    try {
      const res = await axios.post(url, {
        email: 'lightlabcreation@gmail.com',
        password: '123456'
      });
      console.log('Success!', res.data);
    } catch (err) {
      console.log('Error status:', err.response?.status, err.response?.data);
    }
  }
}

testLogins();
