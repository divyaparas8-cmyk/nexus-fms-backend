const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');

const pool = mysql.createPool({
  host: 'hayabusa.proxy.rlwy.net',
  port: 37923,
  user: 'root',
  password: 'KNDOGiJCCQYRBgHLpYTSnCUWKZUddvHO',
  database: 'railway',
});

async function check() {
  try {
    const [users] = await pool.query('SELECT id, email, full_name, role, is_active FROM users');
    console.log('All users:', users);

    const [profiles] = await pool.query('SELECT sp.id, sp.user_id, sp.staff_code, sp.role_title, u.email, u.full_name FROM staff_profiles sp JOIN users u ON sp.user_id = u.id');
    console.log('All staff profiles:', profiles);
  } catch (err) {
    console.error('Error:', err);
  } finally {
    process.exit(0);
  }
}

check();
