const axios = require('axios');

async function testStaff() {
  // Login as admin first
  const loginRes = await axios.post('https://nexus-fms-backend-production.up.railway.app/api/v1/auth/login', {
    email: 'admin@nexusfms.com',
    password: 'Password123!'
  });
  const token = loginRes.data.token;
  console.log('Admin logged in, token:', token.substring(0, 20) + '...');

  const staffRes1 = await axios.get('https://nexus-fms-backend-production.up.railway.app/api/v1/staff', {
    headers: { Authorization: `Bearer ${token}` }
  });
  console.log('\n--- Staff on nexus-fms-backend-production ---');
  console.log(staffRes1.data.data ? staffRes1.data.data.map(s => ({ id: s.id, name: s.name, email: s.email, staffCode: s.staffCode })) : staffRes1.data);

  try {
    const loginRes2 = await axios.post('https://nexusfmsbackednshrikant-production.up.railway.app/api/v1/auth/login', {
      email: 'admin@nexusfms.com',
      password: 'Password123!'
    });
    const staffRes2 = await axios.get('https://nexusfmsbackednshrikant-production.up.railway.app/api/v1/staff', {
      headers: { Authorization: `Bearer ${loginRes2.data.token}` }
    });
    console.log('\n--- Staff on nexusfmsbackednshrikant-production ---');
    console.log(staffRes2.data.data ? staffRes2.data.data.map(s => ({ id: s.id, name: s.name, email: s.email, staffCode: s.staffCode })) : staffRes2.data);
  } catch (e) {
    console.log('Error on 2nd backend:', e.message);
  }
}

testStaff();
