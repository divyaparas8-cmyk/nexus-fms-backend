const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');

const pool = mysql.createPool({
  host: 'hayabusa.proxy.rlwy.net',
  port: 37923,
  user: 'root',
  password: 'KNDOGiJCCQYRBgHLpYTSnCUWKZUddvHO',
  database: 'railway',
});

async function checkDemo() {
  const [users] = await pool.query('SELECT * FROM users WHERE email = ?', ['demo@gmail.com']);
  console.log('Demo user:', users);
  if (users.length > 0) {
    const is123456 = await bcrypt.compare('123456', users[0].password_hash);
    const isDefault = await bcrypt.compare('Password123!', users[0].password_hash);
    console.log('Match 123456:', is123456);
    console.log('Match Password123!:', isDefault);
  }
  process.exit(0);
}

checkDemo();
